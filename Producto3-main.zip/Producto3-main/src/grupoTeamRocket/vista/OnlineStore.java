package grupoTeamRocket.vista;

import grupoTeamRocket.dao.DAOException;

public class OnlineStore {
    public static void main(String[] args){
        GestionOS gestion = new GestionOS();
        gestion.inicio();
    }
}
