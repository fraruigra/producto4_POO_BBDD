package grupoTeamRocket.dao;

import grupoTeamRocket.modelo.Articulo;

public interface ArticuloDAO extends DAO<Articulo, String>{

}
