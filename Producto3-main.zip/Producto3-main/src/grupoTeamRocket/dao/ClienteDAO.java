package grupoTeamRocket.dao;

import grupoTeamRocket.modelo.Cliente;

public interface ClienteDAO extends DAO<Cliente, String>{

}
