package grupoTeamRocket.dao;

import grupoTeamRocket.modelo.ClienteEstandar;

public interface ClienteEstandarDAO extends DAO<ClienteEstandar, Long>{
}
