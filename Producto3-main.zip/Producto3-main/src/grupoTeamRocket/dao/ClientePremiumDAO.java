package grupoTeamRocket.dao;

import grupoTeamRocket.modelo.ClientePremium;

public interface ClientePremiumDAO extends DAO<ClientePremium, Long>{
}

